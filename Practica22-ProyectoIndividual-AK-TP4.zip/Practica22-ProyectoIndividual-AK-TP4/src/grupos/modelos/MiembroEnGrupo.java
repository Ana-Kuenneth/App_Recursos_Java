/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupos.modelos;
import autores.modelos.Autor;
import autores.modelos.Profesor;
import java.util.Objects;

/**
 *
 * @author anaro
 */
public class MiembroEnGrupo {
    //Variables de instancia
    private Autor autor;
    private Grupo grupo;
    private Rol rol;
    
    //Constructor
    public MiembroEnGrupo(Autor autor, Grupo grupo, Rol rol) {
        this.autor = autor;
        this.grupo = grupo;
        this.rol = rol;
    }
    
    //Métodos GET/SET
    public Autor verAutor() {
        return autor;
    }

    public void asignarAutor(Autor autor) {
        this.autor = autor;
    }

    public Grupo verGrupo() {
        return grupo;
    }

    public void asignarGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    public Rol verRol() {
        return rol;
    }

    public void asignarRol(Rol rol) {
        this.rol = rol;
    }
    
    //Métodos
    public void mostrar(){
        System.out.println("Miembro: " + this.autor.verNombres() + " " + this.autor.verApellidos());
        System.out.println("Rol: " + this.rol);
        System.out.println("Grupo: " + this.grupo.verNombre());
    }

    @Override
    public String toString() {
        return "Autor: " + this.verAutor().toString() + "Grupo: " + this.verGrupo().toString() + "\nRol: " +  this.verRol().toString();
    }
    
    //Métodos para comparar los autores(profesores y alumnos): no debe haber autores repetidos
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.autor);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MiembroEnGrupo other = (MiembroEnGrupo) obj;
        return Objects.equals(this.autor, other.autor);
    }   
}
