/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupos.modelos;

import autores.modelos.Autor;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author anaro
 */
public class Grupo {
    //Variables de instancia
    private String nombre;
    private String descripcion;
    private ArrayList<MiembroEnGrupo> miembros = new ArrayList<>();
    
    //Constructor
    public Grupo(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
    
    //Métodos GET/SET
    public String verNombre() {
        return nombre;
    }

    public void asignarNombre(String nombre) {
        this.nombre = nombre;
    }

    public String verDescripcion() {
        return descripcion;
    }

    public void asignarDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
    //Métodos
    public void mostrar(){
        System.out.println("Grupo: "+this.nombre+". Descripcion: "+this.descripcion);
        System.out.println("Miembros del grupo/Autores: ");
        for (MiembroEnGrupo meg : this.verMiembros()) {
            System.out.println("\t" + meg.verAutor().verApellidos() + ", " + meg.verAutor().verNombres() + "  Rol: " + meg.verRol());
        }
    }
    
    public ArrayList<MiembroEnGrupo> verMiembros() {
        return miembros;
    }
    
    public void agregarMiembro(Autor autor, Rol rol) {
        if (this.esSuperAdministradores()) {
            rol = Rol.ADMINISTRADOR;
        }

        MiembroEnGrupo m = new MiembroEnGrupo(autor, this, rol);

        if (!miembros.contains(m)) {
            miembros.add(m);
            autor.agregarGrupo(this, rol);
        }

    }
    
    public void quitarMiembro(Autor miembro) {
        for (MiembroEnGrupo m : miembros) {
            if (m.verAutor().equals(miembro)) {
                miembros.remove(m);
                miembro.quitarGrupo(this);
                break;
            }
        }
    }
    
    public boolean esSuperAdministradores(){
        if(this.nombre.equalsIgnoreCase("super administradores")){
            return true;
        }
        return false;  
    }
    
    public boolean tieneMiembros() {
        if (miembros.isEmpty()) {
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Grupo other = (Grupo) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }    
}
