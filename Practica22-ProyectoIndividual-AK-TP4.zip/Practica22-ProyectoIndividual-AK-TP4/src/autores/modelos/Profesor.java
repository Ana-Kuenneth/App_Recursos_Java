/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autores.modelos;


/**
 *
 * @author anaro
 */
public class Profesor extends Autor{
    //Variables de instancia
    private Cargo cargo;
    
//    ArrayList<MiembroEnGrupo> meg = new ArrayList<>();
    
    //Constructor
    public Profesor(int dni, String apellidos, String nombres, String clave, Cargo cargo) {
        super(dni, apellidos, nombres, clave);
        this.cargo = cargo;
    }
        
    //Métodos GET/SET
    public Cargo verCargo() {
        return cargo;
    }

    public void asignarCargo(Cargo cargo) {
        this.cargo = cargo;
    }
    
    //Métodos
    @Override
    public void mostrar(){
        super.mostrar();
       System.out.println("Cargo: "+this.cargo); 
    }
}
