/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autores.modelos;

import grupos.modelos.Grupo;
import grupos.modelos.MiembroEnGrupo;
import grupos.modelos.Rol;
import java.util.ArrayList;

/**
 *
 * @author anaro
 */
public abstract class Autor {
    //Variables de instancia de Autor, Autor es superclase de Alumno y Profesor
    private int dni;
    private String apellidos;
    private String nombres;
    private String clave;
    private ArrayList<MiembroEnGrupo> miembros = new ArrayList <>();

    //Constructor, es heredado por Alumno y Profesor
    public Autor(int dni, String apellidos, String nombres, String clave) {
        this.dni = dni;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.clave = clave;
    }
    
    //Métodos GET/SET
    public int verDni() {
        return dni;
    }

    public void asignarDni(int dni) {
        this.dni = dni;
    }

    public String verApellidos() {
        return apellidos;
    }

    public void asignarApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String verNombres() {
        return nombres;
    }

    public void asignarNombres(String nombres) {
        this.nombres = nombres;
    }

    public String verClave() {
        return clave;
    }

    public void asignarClave(String clave) {
        this.clave = clave;
    }
    
    
    //Métodos
    public void mostrar(){
        System.out.println("["+this.verDni()+"] "+this.verApellidos()+", "+this.verNombres());
        
        System.out.println("Grupos: ");
        for(MiembroEnGrupo meg: verGrupos()){
            System.out.println("\t"+ meg.verGrupo().verNombre() + "  Rol: "+meg.verRol());
        }
    }
    
    public ArrayList<MiembroEnGrupo> verGrupos(){
        return miembros;
    }
    
    public void agregarGrupo(Grupo grupo, Rol rol){
        MiembroEnGrupo meg = new MiembroEnGrupo(this, grupo, rol);
        
        if(!miembros.contains(meg)){
            this.miembros.add(meg);
            grupo.agregarMiembro(this, rol);
        }
    }
    
    public void quitarGrupo(Grupo grupo) {
        MiembroEnGrupo meg = new MiembroEnGrupo(this, grupo, null);
        
        if (this.miembros.contains(meg)){
            this.miembros.remove(meg);      
            grupo.quitarMiembro(this);
        }
    }
    
//    public void quitarGrupo(Grupo grupo){
//        if(grupo != null){
//            for(MiembroEnGrupo meg : this.miembros){ //pide agregar grupos en Autor
//                Grupo g = meg.verGrupo();
//                if(grupo.equals(g)){
//                    this.miembros.remove(meg);
//                    grupo.quitarMiembro(this);
//                    break;
//                }
//            }
//        }
//        for(MiembroEnGrupo meg : miembros){
//            if(meg.verGrupo().equals(grupo)){
//                miembros.remove(meg);
//                grupo.quitarMiembro(meg.verAutor());
//            }
//        }    
//    }
    
    public boolean esSuperAdministrador(){
        for (MiembroEnGrupo meg : miembros){
            if(meg.verGrupo().verNombre().equalsIgnoreCase("Super Administradores")){
                return true;
            }
        }
        return false;
    }
    
  
    //Métodos para comparar los DNI de los autores(profesores y alumnos): deben ser diferentes
    //Corregido Ingeniero LuisNieto
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.dni;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass().getSuperclass() != obj.getClass().getSuperclass()) {
            return false;
        }
        final Autor other = (Autor) obj;
        return this.dni == other.dni;
    }
}