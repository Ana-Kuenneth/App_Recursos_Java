/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autores.modelos;

import java.util.Objects;

/**
 *
 * @author anaro
 */
public class Alumno extends Autor{
    //Variables de instancia
    private String cx;

    //Constructor
    public Alumno(int dni, String apellidos, String nombres, String clave, String cx) {
        super(dni, apellidos, nombres, clave);
        this.cx = cx;
    }
    
    //Métodos GET/SET
    public String verCx() {
        return cx;
    }

    public void asignarCx(String cx) {
        this.cx = cx;
    }
    
    //Métodos
    @Override
    public void mostrar(){
        super.mostrar();
        System.out.println("CX: "+this.verCx());
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 61 * hash + Objects.hashCode(this.cx);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (super.equals(obj))
            return true;
        else {
            if (obj instanceof Alumno) {
                Alumno a = (Alumno)obj;
                return this.cx.equals(a.cx);
            }
            return false;
        }
    }
}
