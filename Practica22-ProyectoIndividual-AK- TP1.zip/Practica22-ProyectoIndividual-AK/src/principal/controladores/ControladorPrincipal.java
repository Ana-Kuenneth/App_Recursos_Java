/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.controladores;

import autores.modelos.Alumno;
import autores.modelos.Profesor;
import grupos.modelos.Grupo;
import idiomas.modelos.Idioma;
import java.util.ArrayList;
import lugares.modelos.Lugar;
import palabrasclaves.modelos.PalabraClave;
import tipos.modelos.Tipo;

/**
 *
 * @author anaro
 */
public class ControladorPrincipal {
    public static void main(String args[]){
        //Definicion Arraylists para cada clase del proyecto
        ArrayList<Alumno> alumnos = new ArrayList();
        ArrayList<Profesor> profesores = new ArrayList();
        ArrayList<Grupo> grupos = new ArrayList();
        ArrayList<Idioma> idiomas = new ArrayList();
        ArrayList<Lugar> lugares = new ArrayList();
        ArrayList<PalabraClave> palabrasClaves = new ArrayList();
        ArrayList<Tipo> tipos = new ArrayList();
        
        //Se instancian 5 objetos de cada clase
        Alumno alumno1 = new Alumno(1, "Kuenneth", "Ana", "123", "1");
        Alumno alumno2 = new Alumno(2, "Kuenneth", "Rosa", "123", "2");
        Alumno alumno3 = new Alumno(3, "Kuenneth", "Maria", "123", "3");
        Alumno alumno4 = new Alumno(4, "Kuenneth", "Angeles", "123", "4");
        Alumno alumno5 = new Alumno(5, "Kuenneth", "Gloria", "123", "5");
        
        Profesor profesor1 = new Profesor(1, "Palacios", "Don", "321", "Profesor");
        Profesor profesor2 = new Profesor(2, "Palacios", "Don", "321", "Profesor");
        Profesor profesor3 = new Profesor(3, "Palacios", "Don", "321", "Profesor");
        Profesor profesor4 = new Profesor(4, "Palacios", "Don", "321", "Profesor");
        Profesor profesor5 = new Profesor(5, "Palacios", "Don", "321", "Profesor");
        
        Grupo grupo1 = new Grupo("G1", "D1");
        Grupo grupo2 = new Grupo("G2", "D2");
        Grupo grupo3 = new Grupo("G3", "D3");
        Grupo grupo4 = new Grupo("G4", "D4");
        Grupo grupo5 = new Grupo("G5", "D5");
        
        Idioma idioma1 = new Idioma("I1");
        Idioma idioma2 = new Idioma("I2");
        Idioma idioma3 = new Idioma("I3");
        Idioma idioma4 = new Idioma("I4");
        Idioma idioma5 = new Idioma("I5");
        
        Lugar lugar1 = new Lugar("L1");
        Lugar lugar2 = new Lugar("L2");
        Lugar lugar3 = new Lugar("L3");
        Lugar lugar4 = new Lugar("L4");
        Lugar lugar5 = new Lugar("L5");
        
        PalabraClave palabraClave1 = new PalabraClave("PC1");
        PalabraClave palabraClave2 = new PalabraClave("PC2");
        PalabraClave palabraClave3 = new PalabraClave("PC3");
        PalabraClave palabraClave4 = new PalabraClave("PC4");
        PalabraClave palabraClave5 = new PalabraClave("PC5");
        
        Tipo tipo1 = new Tipo("T1");
        Tipo tipo2 = new Tipo("T2");
        Tipo tipo3 = new Tipo("T3");
        Tipo tipo4 = new Tipo("T4");
        Tipo tipo5 = new Tipo("T5");
        
        //Se agregan los objetos a cada ArrayList
        alumnos.add(alumno1);
        alumnos.add(alumno2);
        alumnos.add(alumno3);
        alumnos.add(alumno4);
        alumnos.add(alumno5);
        
        profesores.add(profesor1);
        profesores.add(profesor2);
        profesores.add(profesor3);
        profesores.add(profesor4);
        profesores.add(profesor5);
        
        grupos.add(grupo1);
        grupos.add(grupo2);
        grupos.add(grupo3);
        grupos.add(grupo4);
        grupos.add(grupo5);
        
        idiomas.add(idioma1);
        idiomas.add(idioma2);
        idiomas.add(idioma3);
        idiomas.add(idioma4);
        idiomas.add(idioma5);
        
        lugares.add(lugar1);
        lugares.add(lugar2);
        lugares.add(lugar3);
        lugares.add(lugar4);
        lugares.add(lugar5);
        
        palabrasClaves.add(palabraClave1);
        palabrasClaves.add(palabraClave2);
        palabrasClaves.add(palabraClave3);
        palabrasClaves.add(palabraClave4);
        palabrasClaves.add(palabraClave5);
        
        tipos.add(tipo1);
        tipos.add(tipo2);
        tipos.add(tipo3);
        tipos.add(tipo4);
        tipos.add(tipo5);
        
        //Se recorre y muestran los elementos de cada Arraylist
        
        for(Alumno a : alumnos){
            a.mostrar();
        }
        
        for(Profesor p : profesores){
            p.mostrar();
        }
        
        for(Grupo g : grupos){
            g.mostrar();
        }
        
        for(Idioma i : idiomas){
            System.out.println(i.verNombre());
        }
        
        for(Lugar l : lugares){
            System.out.println(l.verNombre());
        }
        
        for(PalabraClave pc : palabrasClaves){
            System.out.println(pc.verNombre());
        }
        
        for(Tipo t : tipos){
            System.out.println(t.verNombre());
        }
    }
}
