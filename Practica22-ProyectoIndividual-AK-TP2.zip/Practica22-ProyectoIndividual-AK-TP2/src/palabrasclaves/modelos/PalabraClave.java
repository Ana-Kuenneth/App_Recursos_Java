/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package palabrasclaves.modelos;

/**
 *
 * @author anaro
 */
public class PalabraClave {
    //Variables de instancia
    private String nombre;

    //Constructor
    public PalabraClave(String nombre) {
        this.nombre = nombre;
    }
    //Métodos GET/SET
    public String verNombre() {
        return nombre;
    }

    public void asignarNombre(String nombre) {
        this.nombre = nombre;
    }
    
    //Métodos
    public void mostrar(){
        System.out.println("Palabra clave: "+this.verNombre());
    }
    
    @Override
    public String toString(){
        return null;
    }    
}
