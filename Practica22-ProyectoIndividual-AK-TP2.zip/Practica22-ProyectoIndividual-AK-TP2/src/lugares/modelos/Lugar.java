/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lugares.modelos;

/**
 *
 * @author anaro
 */
public class Lugar {
    //Variables de instancia
    private String nombre;

    //Constructor
    public Lugar(String nombre) {
        this.nombre = nombre;
    }
    
    //Métodos GET/SET
    public String verNombre() {
        return nombre;
    }

    public void asignarNombre(String nombre) {
        this.nombre = nombre;
    }
    
    //Métodos
    public void mostrar(){
        System.out.println("Lugar: "+this.verNombre());
    }
    
    @Override
    public String toString(){
        
        return null;
    }
}
