/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package publicaciones.modelos;

import autores.modelos.Profesor;
import idiomas.modelos.Idioma;
import java.time.LocalDate;
import java.util.ArrayList;
import lugares.modelos.Lugar;
import palabrasclaves.modelos.PalabraClave;
import tipos.modelos.Tipo;

/**
 *
 * @author anaro
 */
public class Publicacion {
    //Variables de instancia
    private String titulo;
    private LocalDate fechaPublicacion;
    private String enlace;
    private String resumen;
    
    private Idioma idioma;
    private Lugar lugar;
    private Profesor profesor;
    private Tipo tipo;
    ArrayList<PalabraClave> palabrasClaves = new ArrayList<>();
    
    //Constructor
    public Publicacion(String titulo, Profesor profesor, LocalDate fechaPublicacion, Tipo tipo, Idioma idioma, Lugar lugar, ArrayList<PalabraClave> palabrasClaves, String enlace, String resumen) {
        this.titulo = titulo;
        this.fechaPublicacion = fechaPublicacion;
        this.enlace = enlace;
        this.resumen = resumen;
        this.idioma = idioma;
        this.lugar = lugar;
        this.profesor = profesor;
        this.tipo = tipo;
        this.palabrasClaves = palabrasClaves;
    }

    
    //Métodos GET/SET
    public String verTitulo() {
        return titulo;
    }

    public void asignarTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate verFechaPublicacion() {
        return fechaPublicacion;
    }

    public void asignarFechaPublicacion(LocalDate fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String verEnlace() {
        return enlace;
    }

    public void asignarEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String verResumen() {
        return resumen;
    }

    public void asignarResumen(String resumen) {
        this.resumen = resumen;
    }
    public Lugar verLugar() {
        return lugar;
    }

    public void asignarLugar(Lugar lugar) {
        this.lugar = lugar;
    }

    public Idioma verIdioma() {
        return idioma;
    }

    public void asignarIdioma(Idioma idioma) {
        this.idioma = idioma;
    }

    public Tipo verTipo() {
        return tipo;
    }

    public void asignarTipo(Tipo tipo) {
        this.tipo = tipo;
    }
    
    public Profesor verProfesor() {
        return profesor;
    }

    public void asignarProfesor(Profesor profesor) {
        this.profesor = profesor;
    }
   
    //Métodos
    public void mostrar(){
        System.out.println("Titulo: "+this.verTitulo());
        System.out.println("Autor: "+this.verProfesor().verApellidos()+", "+this.verProfesor().verNombres());
        System.out.println("Fecha de publicacion: "+this.verFechaPublicacion());
        System.out.println("Tipo: "+this.verTipo());
        System.out.println("Idioma: "+this.verIdioma());
        System.out.println("Lugar: "+this.verLugar());
        System.out.println("Palabras claves");
        System.out.println("---------------");
        
        for(PalabraClave pc : palabrasClaves){
            System.out.println("    "+pc.toString());
        }
        
        System.out.println("Enlace: "+this.verEnlace());
        System.out.println("Resumen: "+this.verResumen());
    }
}
