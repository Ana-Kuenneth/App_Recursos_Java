/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupos.modelos;
import autores.modelos.Profesor;

/**
 *
 * @author anaro
 */
public class MiembroEnGrupo {
    //Variables de instancia
    private Profesor profesor;
    private Grupo grupo;
    private Rol rol;
    
    //Constructor
    public MiembroEnGrupo(Profesor profesor, Grupo grupo, Rol rol) {
        this.profesor = profesor;
        this.grupo = grupo;
        this.rol = rol;
    }
    
    //Métodos GET/SET
    public Profesor verProfesor() {
        return profesor;
    }

    public void asignarProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Grupo verGrupo() {
        return grupo;
    }

    public void asignarGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    public Rol verRol() {
        return rol;
    }

    public void asignarRol(Rol rol) {
        this.rol = rol;
    }
    
    //Métodos
       
}
