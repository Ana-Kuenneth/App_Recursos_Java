/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package publicaciones.modelos;

import grupos.modelos.MiembroEnGrupo;
import idiomas.modelos.Idioma;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import lugares.modelos.Lugar;
import palabrasclaves.modelos.PalabraClave;
import tipos.modelos.Tipo;

/**
 *
 * @author anaro
 */
public class Publicacion {
    //Variables de instancia
    private String titulo;
    private LocalDate fechaPublicacion;
    private String enlace;
    private String resumen;
    
    private Idioma idioma;
    private Lugar lugar;
    private MiembroEnGrupo meg;
    private Tipo tipo;
    ArrayList<PalabraClave> palabrasClaves = new ArrayList<>();
    
    String patron = "dd/mm/yyyy";
    String fFormateada = fechaPublicacion.format(DateTimeFormatter.ofPattern(patron));
    
    //Constructor
    public Publicacion(String titulo, MiembroEnGrupo meg, LocalDate fechaPublicacion, Tipo tipo, Idioma idioma, Lugar lugar,List palabrasclave, String enlace, String resumen) {
        this.titulo = titulo;
        this.fechaPublicacion = fechaPublicacion;
        this.enlace = enlace;
        this.resumen = resumen;
        this.idioma = idioma;
        this.lugar = lugar;
        this.meg = meg;
        this.tipo = tipo;
    }
    
    
    //Métodos GET/SET
    public String verTitulo() {
        return titulo;
    }

    public void asignarTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate verFechaPublicacion() {
        return fechaPublicacion;
    }

    public void asignarFechaPublicacion(LocalDate fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String verEnlace() {
        return enlace;
    }

    public void asignarEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String verResumen() {
        return resumen;
    }

    public void asignarResumen(String resumen) {
        this.resumen = resumen;
    }
    public Lugar verLugar() {
        return lugar;
    }

    public void asignarLugar(Lugar lugar) {
        this.lugar = lugar;
    }

    public Idioma verIdioma() {
        return idioma;
    }

    public void asignarIdioma(Idioma idioma) {
        this.idioma = idioma;
    }

    public Tipo verTipo() {
        return tipo;
    }

    public void asignarTipo(Tipo tipo) {
        this.tipo = tipo;
    }
    
    public MiembroEnGrupo verMeg() {
        return meg;
    }

    public void asignarMeg(MiembroEnGrupo meg) {
        this.meg = meg;
    }
   
    //Métodos
    public void mostrar(){
        System.out.println("Titulo: "+this.verTitulo());
        System.out.println("Autor: "+this.verMeg().verProfesor().verApellidos()+", "+this.verMeg().verProfesor().verNombres());
        System.out.println("Grupo: "+this.verMeg().verGrupo());
        System.out.println("Rol: "+this.verMeg().verRol());
        System.out.println("Fecha de publicacion: "+this.fFormateada);
        System.out.println("Tipo: "+this.verTipo());
        System.out.println("Idioma: "+this.verIdioma());
        System.out.println("Lugar: "+this.verLugar());
        System.out.println("Palabras claves");
        System.out.println("---------------");
        
        for(PalabraClave pc : palabrasClaves){
            System.out.println("    "+pc.toString());
        }
        
        System.out.println("Enlace: "+this.verEnlace());
        System.out.println("Resumen: "+this.verResumen());
    }
}
